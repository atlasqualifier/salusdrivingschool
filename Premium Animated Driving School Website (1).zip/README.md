
  # Premium Animated Driving School Website

  This is a code bundle for Premium Animated Driving School Website. The original project is available at https://www.figma.com/design/De6mqX0COuJethJr9Tvt98/Premium-Animated-Driving-School-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  